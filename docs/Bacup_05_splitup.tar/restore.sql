--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.24
-- Dumped by pg_dump version 9.5.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.republica DROP CONSTRAINT fk_republica_imovel1;
ALTER TABLE ONLY public.pensionato DROP CONSTRAINT fk_pensionato_imovel1;
ALTER TABLE ONLY public.morador DROP CONSTRAINT fk_morador_usuario1;
ALTER TABLE ONLY public.morador DROP CONSTRAINT fk_morador_imovel1;
ALTER TABLE ONLY public.mensagem DROP CONSTRAINT fk_mensagem_imovel1;
ALTER TABLE ONLY public.mensagem DROP CONSTRAINT fk_mensage_calouro;
ALTER TABLE ONLY public.imovel DROP CONSTRAINT fk_imovel_morador;
ALTER TABLE ONLY public.facul_rep DROP CONSTRAINT fk_facul_rep_imovel1;
ALTER TABLE ONLY public.calouro DROP CONSTRAINT fk_calouro_usuario1;
ALTER TABLE ONLY public.apartamento DROP CONSTRAINT fk_apartamento_imovel;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.morador DROP CONSTRAINT uc_morador1;
ALTER TABLE ONLY public.imovel DROP CONSTRAINT uc_imovel3;
ALTER TABLE ONLY public.imovel DROP CONSTRAINT uc_imovel2;
ALTER TABLE ONLY public.imovel DROP CONSTRAINT uc_imovel1;
ALTER TABLE ONLY public.republica DROP CONSTRAINT republica_pkey;
ALTER TABLE ONLY public.pensionato DROP CONSTRAINT pensionato_pkey;
ALTER TABLE ONLY public.morador DROP CONSTRAINT morador_pkey;
ALTER TABLE ONLY public.mensagem DROP CONSTRAINT mensagem_pkey;
ALTER TABLE ONLY public.imovel DROP CONSTRAINT imovel_pkey;
ALTER TABLE ONLY public.facul_rep DROP CONSTRAINT facul_rep_pkey;
ALTER TABLE ONLY public.calouro DROP CONSTRAINT calouro_pkey;
ALTER TABLE ONLY public.apartamento DROP CONSTRAINT apartamento_pkey;
ALTER TABLE public.usuario ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.mensagem ALTER COLUMN id_msg DROP DEFAULT;
ALTER TABLE public.imovel ALTER COLUMN id_imovel DROP DEFAULT;
DROP TABLE public.republica;
DROP TABLE public.pensionato;
DROP TABLE public.morador;
DROP SEQUENCE public.imovel_id_imovel_seq;
DROP TABLE public.imovel;
DROP TABLE public.facul_rep;
DROP TABLE public.calouro;
DROP TABLE public.apartamento;
DROP SEQUENCE public."Usuario_id_user_seq";
DROP TABLE public.usuario;
DROP SEQUENCE public."Mensagem_id_msg_seq";
DROP TABLE public.mensagem;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: mensagem; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.mensagem (
    id_msg integer NOT NULL,
    data_msg date,
    texto_msg character varying(400),
    id_calouro integer NOT NULL,
    id_imovel integer NOT NULL,
    lida boolean DEFAULT false NOT NULL
);


ALTER TABLE public.mensagem OWNER TO userman1;

--
-- Name: Mensagem_id_msg_seq; Type: SEQUENCE; Schema: public; Owner: userman1
--

CREATE SEQUENCE public."Mensagem_id_msg_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Mensagem_id_msg_seq" OWNER TO userman1;

--
-- Name: Mensagem_id_msg_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: userman1
--

ALTER SEQUENCE public."Mensagem_id_msg_seq" OWNED BY public.mensagem.id_msg;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.usuario (
    id_user integer NOT NULL,
    nome_user character varying(16) NOT NULL,
    tipo character(10) NOT NULL
);


ALTER TABLE public.usuario OWNER TO userman1;

--
-- Name: Usuario_id_user_seq; Type: SEQUENCE; Schema: public; Owner: userman1
--

CREATE SEQUENCE public."Usuario_id_user_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Usuario_id_user_seq" OWNER TO userman1;

--
-- Name: Usuario_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: userman1
--

ALTER SEQUENCE public."Usuario_id_user_seq" OWNED BY public.usuario.id_user;


--
-- Name: apartamento; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.apartamento (
    id_imovel integer NOT NULL,
    nome_ap character varying(20)
);


ALTER TABLE public.apartamento OWNER TO userman1;

--
-- Name: calouro; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.calouro (
    id_calouro integer NOT NULL,
    telefone character(17),
    email character varying(30),
    faculdade character varying(10)
);


ALTER TABLE public.calouro OWNER TO userman1;

--
-- Name: facul_rep; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.facul_rep (
    id_imovel integer NOT NULL,
    nome_facul character varying(20) NOT NULL
);


ALTER TABLE public.facul_rep OWNER TO userman1;

--
-- Name: imovel; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.imovel (
    id_imovel integer NOT NULL,
    rua character varying(40) NOT NULL,
    numero smallint NOT NULL,
    bairro character varying(30) NOT NULL,
    tipo character(15) NOT NULL,
    nome_resp character varying(20) NOT NULL,
    curso_resp character varying(30) NOT NULL,
    email_resp character varying(30) NOT NULL,
    complemento character varying(15),
    num_moradores smallint,
    genero character(9),
    val_medio_aluguel real,
    descricao_local text,
    link_album text,
    id_mor_admin integer
);


ALTER TABLE public.imovel OWNER TO userman1;

--
-- Name: imovel_id_imovel_seq; Type: SEQUENCE; Schema: public; Owner: userman1
--

CREATE SEQUENCE public.imovel_id_imovel_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.imovel_id_imovel_seq OWNER TO userman1;

--
-- Name: imovel_id_imovel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: userman1
--

ALTER SEQUENCE public.imovel_id_imovel_seq OWNED BY public.imovel.id_imovel;


--
-- Name: morador; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.morador (
    id_morador integer NOT NULL,
    usuario character varying(16) NOT NULL,
    senha character varying(16) NOT NULL,
    admin boolean NOT NULL,
    id_imovel integer
);


ALTER TABLE public.morador OWNER TO userman1;

--
-- Name: pensionato; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.pensionato (
    id_imovel integer NOT NULL,
    restricao character varying(100)
);


ALTER TABLE public.pensionato OWNER TO userman1;

--
-- Name: republica; Type: TABLE; Schema: public; Owner: userman1
--

CREATE TABLE public.republica (
    id_imovel integer NOT NULL,
    nome_rep character varying(20)
);


ALTER TABLE public.republica OWNER TO userman1;

--
-- Name: id_imovel; Type: DEFAULT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel ALTER COLUMN id_imovel SET DEFAULT nextval('public.imovel_id_imovel_seq'::regclass);


--
-- Name: id_msg; Type: DEFAULT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.mensagem ALTER COLUMN id_msg SET DEFAULT nextval('public."Mensagem_id_msg_seq"'::regclass);


--
-- Name: id_user; Type: DEFAULT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id_user SET DEFAULT nextval('public."Usuario_id_user_seq"'::regclass);


--
-- Name: Mensagem_id_msg_seq; Type: SEQUENCE SET; Schema: public; Owner: userman1
--

SELECT pg_catalog.setval('public."Mensagem_id_msg_seq"', 1, false);


--
-- Name: Usuario_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: userman1
--

SELECT pg_catalog.setval('public."Usuario_id_user_seq"', 13, true);


--
-- Data for Name: apartamento; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1959.dat

--
-- Data for Name: calouro; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1961.dat

--
-- Data for Name: facul_rep; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1963.dat

--
-- Data for Name: imovel; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1965.dat

--
-- Name: imovel_id_imovel_seq; Type: SEQUENCE SET; Schema: public; Owner: userman1
--

SELECT pg_catalog.setval('public.imovel_id_imovel_seq', 4, true);


--
-- Data for Name: mensagem; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1957.dat

--
-- Data for Name: morador; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1962.dat

--
-- Data for Name: pensionato; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1960.dat

--
-- Data for Name: republica; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1958.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: userman1
--

\i $$PATH$$/1955.dat

--
-- Name: apartamento_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.apartamento
    ADD CONSTRAINT apartamento_pkey PRIMARY KEY (id_imovel);


--
-- Name: calouro_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.calouro
    ADD CONSTRAINT calouro_pkey PRIMARY KEY (id_calouro);


--
-- Name: facul_rep_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.facul_rep
    ADD CONSTRAINT facul_rep_pkey PRIMARY KEY (id_imovel, nome_facul);


--
-- Name: imovel_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel
    ADD CONSTRAINT imovel_pkey PRIMARY KEY (id_imovel);


--
-- Name: mensagem_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.mensagem
    ADD CONSTRAINT mensagem_pkey PRIMARY KEY (id_msg);


--
-- Name: morador_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.morador
    ADD CONSTRAINT morador_pkey PRIMARY KEY (id_morador);


--
-- Name: pensionato_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.pensionato
    ADD CONSTRAINT pensionato_pkey PRIMARY KEY (id_imovel);


--
-- Name: republica_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.republica
    ADD CONSTRAINT republica_pkey PRIMARY KEY (id_imovel);


--
-- Name: uc_imovel1; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel
    ADD CONSTRAINT uc_imovel1 UNIQUE (rua, numero, bairro);


--
-- Name: uc_imovel2; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel
    ADD CONSTRAINT uc_imovel2 UNIQUE (email_resp);


--
-- Name: uc_imovel3; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel
    ADD CONSTRAINT uc_imovel3 UNIQUE (nome_resp, curso_resp, email_resp);


--
-- Name: uc_morador1; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.morador
    ADD CONSTRAINT uc_morador1 UNIQUE (usuario);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_user);


--
-- Name: fk_apartamento_imovel; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.apartamento
    ADD CONSTRAINT fk_apartamento_imovel FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel);


--
-- Name: fk_calouro_usuario1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.calouro
    ADD CONSTRAINT fk_calouro_usuario1 FOREIGN KEY (id_calouro) REFERENCES public.usuario(id_user) ON DELETE CASCADE;


--
-- Name: fk_facul_rep_imovel1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.facul_rep
    ADD CONSTRAINT fk_facul_rep_imovel1 FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel);


--
-- Name: fk_imovel_morador; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.imovel
    ADD CONSTRAINT fk_imovel_morador FOREIGN KEY (id_mor_admin) REFERENCES public.morador(id_morador);


--
-- Name: fk_mensage_calouro; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.mensagem
    ADD CONSTRAINT fk_mensage_calouro FOREIGN KEY (id_calouro) REFERENCES public.calouro(id_calouro);


--
-- Name: fk_mensagem_imovel1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.mensagem
    ADD CONSTRAINT fk_mensagem_imovel1 FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel);


--
-- Name: fk_morador_imovel1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.morador
    ADD CONSTRAINT fk_morador_imovel1 FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel) ON UPDATE CASCADE ON DELETE SET DEFAULT;


--
-- Name: fk_morador_usuario1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.morador
    ADD CONSTRAINT fk_morador_usuario1 FOREIGN KEY (id_morador) REFERENCES public.usuario(id_user);


--
-- Name: fk_pensionato_imovel1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.pensionato
    ADD CONSTRAINT fk_pensionato_imovel1 FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_republica_imovel1; Type: FK CONSTRAINT; Schema: public; Owner: userman1
--

ALTER TABLE ONLY public.republica
    ADD CONSTRAINT fk_republica_imovel1 FOREIGN KEY (id_imovel) REFERENCES public.imovel(id_imovel) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

